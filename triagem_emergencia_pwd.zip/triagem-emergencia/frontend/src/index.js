import React from 'react';
import ReactDOM from 'react-dom/client';
const App = () => <h1>Sistema de Triagem Emergencial (Docker OK)</h1>;
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
